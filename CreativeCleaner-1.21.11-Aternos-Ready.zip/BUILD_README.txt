CreativeCleaner - Minecraft 1.21.11 Fabric

This project is configured for Java 21 and Fabric Loom remapping for Minecraft 1.21.11.

LOCAL BUILD (if Gradle is installed):
  gradle build

The finished mod will be in:
  build/libs/

GITHUB BUILD (recommended):
1. Create a GitHub repository.
2. Upload all files/folders from this project, including .github/workflows/build.yml.
3. Open Actions -> Build CreativeCleaner -> Run workflow.
4. When it finishes, open the workflow run and download the artifact named:
   CreativeCleaner-1.21.11
5. Put the resulting .jar into Aternos -> Files -> mods.

SERVER REQUIREMENTS:
- Minecraft Java 1.21.11
- Fabric server
- Java 21
- Fabric API 0.141.0+1.21.11

The mod is server-side; players do not need to install it on their clients.
