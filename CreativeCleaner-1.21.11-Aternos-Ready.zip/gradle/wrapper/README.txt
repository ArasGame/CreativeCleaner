Gradle Wrapper placeholder.
Run `gradle wrapper --gradle-version 8.14.3` once on a machine with Gradle installed,
then use ./gradlew build.
