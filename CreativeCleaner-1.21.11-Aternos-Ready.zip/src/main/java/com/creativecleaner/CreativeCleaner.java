package com.creativecleaner;

import com.creativecleaner.command.CreativeCleanerCommands;
import com.creativecleaner.component.ModComponents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.block.entity.BlockEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public final class CreativeCleaner implements ModInitializer {
    public static final String MOD_ID = "creativecleaner";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final long DEFAULT_INTERVAL_TICKS = 100L;
    private static long intervalTicks = DEFAULT_INTERVAL_TICKS;
    private static long tickCounter;
    private static int lastRemoved;

    @Override
    public void onInitialize() {
        // Force component registration during mod initialization.
        ModComponents.CREATIVE_ITEM.toString();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                CreativeCleanerCommands.register(dispatcher));

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            tickCounter = 0;
            lastRemoved = scanAllLoaded(server);
            LOGGER.info("CreativeCleaner started; initial loaded scan removed {} marked stack(s).", lastRemoved);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            if (tickCounter >= intervalTicks) {
                tickCounter = 0;
                lastRemoved = scanAllLoaded(server);
            }
        });

        reloadConfig();
        LOGGER.info("CreativeCleaner {} initialized for Minecraft 1.21.11.", "1.0.0");
    }

    public static void mark(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return;
        stack.set(ModComponents.CREATIVE_ITEM, true);
    }

    public static boolean isMarked(ItemStack stack) {
        return stack != null && !stack.isEmpty()
                && stack.getOrDefault(ModComponents.CREATIVE_ITEM, false);
    }

    /**
     * Removes only explicitly marked stacks. It never guesses whether an unmarked item
     * came from Creative, so pre-mod Creative items remain untouched.
     */
    public static int scanAllLoaded(MinecraftServer server) {
        AtomicInteger removed = new AtomicInteger();

        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            removed.addAndGet(scanInventory(player.getInventory()));
            removed.addAndGet(scanInventory(player.getEnderChestInventory()));
        }

        for (ServerWorld world : server.getWorlds()) {
            // Loaded chunks only: forEachChunk does not generate new chunks.
            world.getChunkManager().chunkLoadingManager.forEachChunk(chunk ->
                    scanChunk(chunk, removed));

            for (ItemEntity entity : world.getEntitiesByType(EntityType.ITEM, e -> true)) {
                ItemStack stack = entity.getStack();
                if (sanitizeStackOrRemoveEntity(entity, stack)) {
                    removed.incrementAndGet();
                }
            }

            for (ItemFrameEntity frame : world.getEntitiesByType(EntityType.ITEM_FRAME, e -> true)) {
                ItemStack stack = frame.getHeldItemStack();
                if (isMarked(stack)) {
                    frame.setHeldItemStack(ItemStack.EMPTY);
                    removed.incrementAndGet();
                } else if (sanitizeNested(stack)) {
                    frame.setHeldItemStack(stack);
                }
            }

            for (ItemFrameEntity frame : world.getEntitiesByType(EntityType.GLOW_ITEM_FRAME, e -> true)) {
                ItemStack stack = frame.getHeldItemStack();
                if (isMarked(stack)) {
                    frame.setHeldItemStack(ItemStack.EMPTY);
                    removed.incrementAndGet();
                } else if (sanitizeNested(stack)) {
                    frame.setHeldItemStack(stack);
                }
            }
        }

        return removed.get();
    }

    private static void scanChunk(WorldChunk chunk, AtomicInteger removed) {
        for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
            if (blockEntity instanceof Inventory inventory) {
                removed.addAndGet(scanInventory(inventory));
            }
        }
    }

    private static int scanInventory(Inventory inventory) {
        int removed = 0;
        for (int slot = 0; slot < inventory.size(); slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.isEmpty()) continue;

            if (isMarked(stack)) {
                inventory.setStack(slot, ItemStack.EMPTY);
                removed++;
                continue;
            }

            if (sanitizeNested(stack)) {
                inventory.setStack(slot, stack);
            }
        }
        return removed;
    }

    /**
     * Recursively sanitizes item-container components such as shulker-box contents.
     * The parent is retained unless the parent itself carries the Creative marker.
     */
    private static boolean sanitizeNested(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        boolean changed = false;

        ContainerComponent container = stack.get(DataComponentTypes.CONTAINER);
        if (container != null) {
            List<ItemStack> rebuilt = new ArrayList<>();
            boolean containerChanged = false;

            for (ItemStack child : container.stream().toList()) {
                ItemStack copy = child.copy();
                if (copy.isEmpty()) {
                    rebuilt.add(copy);
                    continue;
                }

                if (isMarked(copy)) {
                    rebuilt.add(ItemStack.EMPTY);
                    containerChanged = true;
                    continue;
                }

                if (sanitizeNested(copy)) {
                    containerChanged = true;
                }
                rebuilt.add(copy);
            }

            if (containerChanged) {
                stack.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(rebuilt));
                changed = true;
            }
        }

        return changed;
    }

    private static boolean sanitizeStackOrRemoveEntity(ItemEntity entity, ItemStack stack) {
        if (isMarked(stack)) {
            entity.discard();
            return true;
        }
        return sanitizeNested(stack);
    }

    public static void reloadConfig() {
        // Kept intentionally simple: 5 seconds is the built-in safe default.
        intervalTicks = DEFAULT_INTERVAL_TICKS;
    }

    public static int getIntervalSeconds() {
        return (int) (intervalTicks / 20L);
    }

    public static int getLastRemoved() {
        return lastRemoved;
    }
}
