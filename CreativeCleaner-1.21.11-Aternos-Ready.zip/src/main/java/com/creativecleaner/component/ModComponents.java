package com.creativecleaner.component;

import com.creativecleaner.CreativeCleaner;
import com.mojang.serialization.Codec;
import net.minecraft.component.DataComponentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModComponents {
    private ModComponents() {}

    public static final DataComponentType<Boolean> CREATIVE_ITEM = Registry.register(
            Registries.DATA_COMPONENT_TYPE,
            Identifier.of(CreativeCleaner.MOD_ID, "creative_item"),
            DataComponentType.<Boolean>builder().persistent(Codec.BOOL).build()
    );
}
