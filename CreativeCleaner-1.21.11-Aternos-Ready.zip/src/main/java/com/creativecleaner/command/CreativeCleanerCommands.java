package com.creativecleaner.command;

import com.creativecleaner.CreativeCleaner;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

public final class CreativeCleanerCommands {
    private CreativeCleanerCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("creativecleaner")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.literal("scan")
                        .executes(ctx -> {
                            int removed = CreativeCleaner.scanAllLoaded(ctx.getSource().getServer());
                            ctx.getSource().sendFeedback(() -> net.minecraft.text.Text.literal("CreativeCleaner removed " + removed + " marked stack(s)."), true);
                            return removed;
                        }))
                .then(CommandManager.literal("reload")
                        .executes(ctx -> {
                            CreativeCleaner.reloadConfig();
                            ctx.getSource().sendFeedback(() -> net.minecraft.text.Text.literal("CreativeCleaner reloaded. Scan interval: " + CreativeCleaner.getIntervalSeconds() + "s"), true);
                            return 1;
                        }))
                .then(CommandManager.literal("status")
                        .executes(ctx -> {
                            ctx.getSource().sendFeedback(() -> net.minecraft.text.Text.literal(
                                    "CreativeCleaner: enabled, interval=" + CreativeCleaner.getIntervalSeconds() + "s, last scan removed=" + CreativeCleaner.getLastRemoved()), true);
                            return 1;
                        })));
    }
}
