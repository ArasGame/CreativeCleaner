package com.creativecleaner.mixin;

import com.creativecleaner.CreativeCleaner;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ServerPlayNetworkHandler.class)
public abstract class ServerPlayNetworkHandlerMixin {
    @Shadow net.minecraft.server.network.ServerPlayerEntity player;

    @Inject(method = "onCreativeInventoryAction", at = @At("HEAD"))
    private void creativecleaner$markCreativeStack(CreativeInventoryActionC2SPacket packet, CallbackInfo ci) {
        if (player != null && player.getAbilities().creative && !packet.stack().isEmpty()) {
            CreativeCleaner.mark(packet.stack());
        }
    }
}
